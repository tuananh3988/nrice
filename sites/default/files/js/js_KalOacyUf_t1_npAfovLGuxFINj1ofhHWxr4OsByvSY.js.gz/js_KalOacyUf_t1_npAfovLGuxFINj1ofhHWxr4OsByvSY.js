Drupal.locale = { 'strings': {"":{"An AJAX HTTP error occurred.":"Có lỗi AJAX HTTP.", "HTTP Result Code: !status":"Kết quả mã HTTP: !status", "An AJAX HTTP request terminated abnormally.":"Yêu cầu AJAX HTTP kết thúc bất thường.", "Debugging information follows.":"Rà lỗi theo thông tin sau.", "Path: !uri":"Đường dẫn: !uri", "StatusText: !statusText":"StatusText: !statusText", "ResponseText: !responseText":"ResponseTextt: !responseText", "ReadyState: !readyState":"ReadyState: !readyState", "Edit":"Sửa", "Configure":"Cấu hình", "Done":"Xong", "Anonymous users":"Người dùng nặc danh", "@title dialog":"Hộp thoại @title", "(active tab)":"(tab hoạt động)", "Loading":"Đang nạp", "Re-order rows by numerical weight instead of dragging.":"Sắp xếp lại danh mục theo độ nặng thay vì kéo chúng.", "Show row weights":"Hiện trọng số hàng", "Hide row weights":"Ẩn trọng số hàng", "Drag to re-order":"Kéo để sắp xếp lại", "Changes made in this table will not be saved until the form is submitted.":"Các thay đổi được thực hiện trong bảng này sẽ không được lưu cho đến khi biểu mẫu được đệ trình.", "Customize dashboard":"Sửa cấu hình khối", "Not restricted":"Không hạn chế", "Restricted to certain pages":"Hạn chế đối với một số trang", "Not customizable":"Người dùng không được phép tùy chỉnh", "The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\u002Fem\u003E button is clicked.":"Các thay đổi đối với các khối nội dung này sẽ chưa được lưu cho đến khi nút \u003Cem\u003ELưu các khối nội dung\u003C\u002Fem\u003E được nhấp.", "The block cannot be placed in this region.":"Không thể đưa khối này vào vùng này.", "Hide":"Ẩn", "Show":"Hiện", "Not published":"Chưa công bố", "Hide summary":"Ẩn tóm tắt", "Edit summary":"Sửa nội dung", "Please wait...":"Vui lòng đợi...", "The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"Tên tệp %filename không được phép tải lên. Chỉ có các tệp với phần mở rộng sau là được phép: %extensions.", "Not in menu":"Không có trong trình đơn", "No revision":"Không có phiên bản nào", "By @name on @date":"Bởi @name vào lúc @date", "@number comments per page":"@number lời bình mỗi trang", "Alias: @alias":"Đường dẫn ảo: @alias", "No alias":"Chưa có URL", "Requires a title":"Phần tiêu đề là bắt buộc", "Don\u0027t display post information":"Hiển thị thoại thông tin chữ", "Select all rows in this table":"Chọn tất cả các dòng trong bảng này", "Deselect all rows in this table":"Bỏ chọn tất cả các dòng trong bảng này"}} };;

(function ($) {
  Drupal.Panels = {};

  Drupal.Panels.autoAttach = function() {
    if ($.browser.msie) {
      // If IE, attach a hover event so we can see our admin links.
      $("div.panel-pane").hover(
        function() {
          $('div.panel-hide', this).addClass("panel-hide-hover"); return true;
        },
        function() {
          $('div.panel-hide', this).removeClass("panel-hide-hover"); return true;
        }
      );
      $("div.admin-links").hover(
        function() {
          $(this).addClass("admin-links-hover"); return true;
        },
        function(){
          $(this).removeClass("admin-links-hover"); return true;
        }
      );
    }
  };

  $(Drupal.Panels.autoAttach);
})(jQuery);
;
/**
 * @file
 * Adds effects and behaviors to elements on the checkout page.
 */

Drupal.behaviors.ucCart = {
  attach: function(context, settings) {
    // Add a throbber to the submit order button on the review order form.
    jQuery('form#uc-cart-checkout-review-form input#edit-submit:not(.ucSubmitOrderThrobber-processed)', context).addClass('ucSubmitOrderThrobber-processed').click(function() {
      jQuery(this).clone().insertAfter(this).attr('disabled', true).after('<span class="ubercart-throbber">&nbsp;&nbsp;&nbsp;&nbsp;</span>').end().hide();
      jQuery('#uc-cart-checkout-review-form #edit-back').attr('disabled', true);
    });
  }
}

/**
 * Behaviors for the Next buttons.
 *
 * When a customer clicks a Next button, expand the next pane, remove the
 * button, and don't let it collapse again.
 */
function uc_cart_next_button_click(button, pane_id, current) {
  if (current !== 'false') {
    jQuery('#' + current + '-pane legend a').click();
  }
  else {
    button.disabled = true;
  }

  if (jQuery('#' + pane_id + '-pane').attr('class').indexOf('collapsed') > -1 && jQuery('#' + pane_id + '-pane').html() !== null) {
    jQuery('#' + pane_id + '-pane legend a').click();
  }

  return false;
}
;
(function ($) {

/**
 * Attaches sticky table headers.
 */
Drupal.behaviors.tableHeader = {
  attach: function (context, settings) {
    if (!$.support.positionFixed) {
      return;
    }

    $('table.sticky-enabled', context).once('tableheader', function () {
      $(this).data("drupal-tableheader", new Drupal.tableHeader(this));
    });
  }
};

/**
 * Constructor for the tableHeader object. Provides sticky table headers.
 *
 * @param table
 *   DOM object for the table to add a sticky header to.
 */
Drupal.tableHeader = function (table) {
  var self = this;

  this.originalTable = $(table);
  this.originalHeader = $(table).children('thead');
  this.originalHeaderCells = this.originalHeader.find('> tr > th');

  // Clone the table header so it inherits original jQuery properties. Hide
  // the table to avoid a flash of the header clone upon page load.
  this.stickyTable = $('<table class="sticky-header"/>')
    .insertBefore(this.originalTable)
    .css({ position: 'fixed', top: '0px' });
  this.stickyHeader = this.originalHeader.clone(true)
    .hide()
    .appendTo(this.stickyTable);
  this.stickyHeaderCells = this.stickyHeader.find('> tr > th');

  this.originalTable.addClass('sticky-table');
  $(window)
    .bind('scroll.drupal-tableheader', $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    .bind('resize.drupal-tableheader', { calculateWidth: true }, $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    // Make sure the anchor being scrolled into view is not hidden beneath the
    // sticky table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceAnchor.drupal-tableheader', function () {
      window.scrollBy(0, -self.stickyTable.outerHeight());
    })
    // Make sure the element being focused is not hidden beneath the sticky
    // table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceFocus.drupal-tableheader', function (event) {
      if (self.stickyVisible && event.clientY < (self.stickyOffsetTop + self.stickyTable.outerHeight()) && event.$target.closest('sticky-header').length === 0) {
        window.scrollBy(0, -self.stickyTable.outerHeight());
      }
    })
    .triggerHandler('resize.drupal-tableheader');

  // We hid the header to avoid it showing up erroneously on page load;
  // we need to unhide it now so that it will show up when expected.
  this.stickyHeader.show();
};

/**
 * Event handler: recalculates position of the sticky table header.
 *
 * @param event
 *   Event being triggered.
 */
Drupal.tableHeader.prototype.eventhandlerRecalculateStickyHeader = function (event) {
  var self = this;
  var calculateWidth = event.data && event.data.calculateWidth;

  // Reset top position of sticky table headers to the current top offset.
  this.stickyOffsetTop = Drupal.settings.tableHeaderOffset ? eval(Drupal.settings.tableHeaderOffset + '()') : 0;
  this.stickyTable.css('top', this.stickyOffsetTop + 'px');

  // Save positioning data.
  var viewHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
  if (calculateWidth || this.viewHeight !== viewHeight) {
    this.viewHeight = viewHeight;
    this.vPosition = this.originalTable.offset().top - 4 - this.stickyOffsetTop;
    this.hPosition = this.originalTable.offset().left;
    this.vLength = this.originalTable[0].clientHeight - 100;
    calculateWidth = true;
  }

  // Track horizontal positioning relative to the viewport and set visibility.
  var hScroll = document.documentElement.scrollLeft || document.body.scrollLeft;
  var vOffset = (document.documentElement.scrollTop || document.body.scrollTop) - this.vPosition;
  this.stickyVisible = vOffset > 0 && vOffset < this.vLength;
  this.stickyTable.css({ left: (-hScroll + this.hPosition) + 'px', visibility: this.stickyVisible ? 'visible' : 'hidden' });

  // Only perform expensive calculations if the sticky header is actually
  // visible or when forced.
  if (this.stickyVisible && (calculateWidth || !this.widthCalculated)) {
    this.widthCalculated = true;
    // Resize header and its cell widths.
    this.stickyHeaderCells.each(function (index) {
      var cellWidth = self.originalHeaderCells.eq(index).css('width');
      // Exception for IE7.
      if (cellWidth == 'auto') {
        cellWidth = self.originalHeaderCells.get(index).clientWidth + 'px';
      }
      $(this).css('width', cellWidth);
    });
    this.stickyTable.css('width', this.originalTable.css('width'));
  }
};

})(jQuery);
;
